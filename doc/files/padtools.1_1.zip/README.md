PadTools 1.1
======================================

概要
------------------------------------------------
PadTools はPAD図を活用することを目的として作成された、PAD作成ツールです。
思考を止めず記述できることを目指しています。

動作環境
------------------------------------------------
* Windows10 JRE 1.7

上記の環境で動作を確認しております。
その他環境でも、JRE1.7が動作するOSであれば動作する可能性がありますが、
上記環境以外では動作確認はおこなっておりません。

ライセンス
------------------------------------------------
    Copyright (c) 2015-2016 naou
    
    Released under the MIT license(http://opensource.org/licenses/mit-license)

リンク
------------------------------------------------
* GitHub [https://github.com/knaou/padtools](https://github.com/knaou/padtools)
* 公開サイト [http://naou.cool-ex.com/padtools/](http://naou.cool-ex.com/padtools/)
    * 利用法などは公開サイトを参照

