#!/bin/sh

DIR=`dirname $0`

java -jar $DIR/PadTools.jar -- $@

