PadTools 1.0
======================================

概要
------------------------------------------------
PadTools はPAD図を活用することを目的としています。
思考を止めず記述できることを目指しています。

動作環境
------------------------------------------------
* Windows7 JRE 1.6
* MacOSX JRE 1.6

上記の環境で動作を確認しております。
その他環境でも、JRE1.6が動作するOSであれば動作する可能性がありますが、
上記環境以外では動作確認はおこなっておりません。

リンク
------------------------------------------------
* GitHub [https://github.com/knaou/padtools](https://github.com/knaou/padtools)
* 公開サイト [http://naou.cool-ex.com/padtools/](http://naou.cool-ex.com/padtools/)
    * 利用法などは公開サイトを参照

権利
------------------------------------------------
Copyright (c) 2015 naou
Released under the MIT license(http://opensource.org/licenses/mit-license)
